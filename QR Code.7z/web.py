from flask import Flask, request, render_template_string
import qrcode
import os

app = Flask(__name__)

# Ensure the 'static' directory exists
if not os.path.exists('static'):
    os.makedirs('static')

@app.route('/', methods=['GET', 'POST'])
def home():
    qr_image = None
    character_count = None
    version = None
    if request.method == 'POST':
        url = request.form['url']
        character_count = sum(1 for char in url if char)

        # Determine the appropriate version based on character count
        if character_count <= 17:
            version = 1
        elif character_count <= 32:
            version = 2
        elif character_count <= 53:
            version = 3
        else:
            version = 4

        # Create the QR code
        qr = qrcode.QRCode(
            version=version,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(url)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        img_path = "static/qr_code.png"
        img.save(img_path)
        qr_image = img_path

    # HTML template to accept URL and display QR code
    html_template = '''
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <title>QR Code Generator</title>
      </head>
      <body>
        <h1>QR Code Generator</h1>
        <form method="post">
          <label for="url">Enter URL:</label>
          <input type="text" id="url" name="url" required>
          <button type="submit">Generate QR Code</button>
        </form>
        {% if qr_image %}
        <h2>Your QR Code:</h2>
        <img src="/{{ qr_image }}" alt="QR Code">
        <p>URL Character Count: {{ character_count }}</p>
        <p>QR Code Version: {{ version }}</p>
        {% endif %}
      </body>
    </html>
    '''

    return render_template_string(html_template, qr_image=qr_image, character_count=character_count, version=version)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)